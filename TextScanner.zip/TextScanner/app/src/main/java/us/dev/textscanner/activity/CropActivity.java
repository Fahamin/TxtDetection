package us.dev.textscanner.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;

import us.dev.textscanner.R;

public class CropActivity extends AppCompatActivity {
    public static Bitmap croppedImage;
    public static Uri uriImage;
    private CropImageView cropImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        File filePath = new File(Environment.getExternalStorageDirectory() +
                MainActivity.DIRECTORY_PATH);
        File fileImage = new File(filePath, MainActivity.FILE_NAMES.get(MainActivity.CURRENT_PAGE));
        uriImage = Uri.fromFile(fileImage);

        // Set URI image to display
        cropImageView = (CropImageView) findViewById(R.id.cropImageView);
        cropImageView.setImageUriAsync(Uri.parse(uriImage.toString()));

        // Rotate image the cropped image using function and angle
        // cropImageView.rotateImage(angle);
        // For ex., cropImageView.rotateImage(-90);
    }

    public void onClick(View view) {
        cropImageView.setOnCropImageCompleteListener(new CropImageView.OnCropImageCompleteListener() {
            @Override
            public void onCropImageComplete(CropImageView view, CropImageView.CropResult result) {
                croppedImage = result.getBitmap();
                startActivity(new Intent(CropActivity.this, BinarizationActivity.class));

            }
        });
        cropImageView.getCroppedImageAsync();
    }
}
