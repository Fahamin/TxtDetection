package us.dev.textscanner.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;

import com.googlecode.leptonica.android.GrayQuant;
import com.googlecode.leptonica.android.Pix;

import us.dev.textscanner.R;
import us.dev.textscanner.utils.OtsuThresholder;

public class BinarizationActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {
    public static Bitmap umbralization;
    private Pix pix;
    private ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_binarization);

        img = (ImageView) findViewById(R.id.croppedImage);

        pix = com.googlecode.leptonica.android.ReadFile.readBitmap(CropActivity.croppedImage);
        OtsuThresholder otsuThresholder = new OtsuThresholder();
        int threshold = otsuThresholder.doThreshold(pix.getData());
        /* Increasing value of threshold is better */
        threshold += 20;
        umbralization = com.googlecode.leptonica.android.WriteFile.writeBitmap
                (GrayQuant.pixThresholdToBinary(pix, threshold));
        img.setImageBitmap(umbralization);
        SeekBar seekBar =  findViewById(R.id.umbralization);
        seekBar.setProgress((50 * threshold) / 254);
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) this);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        umbralization = com.googlecode.leptonica.android.WriteFile.writeBitmap(
                GrayQuant.pixThresholdToBinary(pix, ((254 * seekBar.getProgress()) / 50)));
        img.setImageBitmap(umbralization);
    }

    public void onClick(View view) {
        startActivity(new Intent(BinarizationActivity.this, RecognizerActivity.class));

    }
}
