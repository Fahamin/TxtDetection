package us.dev.textscanner.utils;

import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class Contans {
    public static String TITLE = "tt";
    public static int TOTAL_PAGES=11;
    public static String CONTENT="";
    public static int CURRENT_PAGE=0;
    public static String DIRECTORY_PATH = "/Android/data";
    public static ArrayList<String> FILE_NAMES = new ArrayList<>();

}
