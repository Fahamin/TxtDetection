package us.dev.textscanner.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import us.dev.textscanner.R;
import us.dev.textscanner.utils.ContactWriter;
import us.dev.textscanner.utils.PdfGenerator;

public class RecognizerActivity extends AppCompatActivity {
    private TextView textExtracted;
    private ProgressDialog progressCopy;
    private ProgressDialog progressOcr;
    private String textScanned;     // textScanned has extracted text output
    private String DATA_PATH = Environment.getExternalStorageDirectory().getAbsolutePath() +
            MainActivity.DIRECTORY_PATH + File.separator;
    private AsyncTask<Void, Void, Void> copy = new copyTask();
    private AsyncTask<Void, Void, Void> ocr = new ocrTask();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recognizer);

        initActivity();

        copy.execute();
        ocr.execute();
    }

    private void initActivity() {
        textExtracted = (TextView) findViewById(R.id.textExtracted);
        textExtracted.setMovementMethod(new ScrollingMovementMethod());
        //  search = (EditText) findViewById(R.id.search_text);
        // Setting progress dialog for copy job.
        progressCopy = new ProgressDialog(RecognizerActivity.this);
        progressCopy.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressCopy.setIndeterminate(true);
        progressCopy.setCancelable(false);
        progressCopy.setTitle("Dictionaries");
        progressCopy.setMessage("Copying dictionary files");
        // Setting progress dialog for ocr job.
        progressOcr = new ProgressDialog(this);
        progressOcr.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressOcr.setIndeterminate(true);
        progressOcr.setCancelable(false);
        progressOcr.setTitle("OCR");
        progressOcr.setMessage("Extracting text, please wait");
        textScanned = "";
        Button mFab = findViewById(R.id.nextStep);
        mFab.setOnClickListener((View.OnClickListener) RecognizerActivity.this);
    }

    // Copy assets trainneddata to tessdata in External Storage
    private void copyAssets() {
        AssetManager assetManager = getAssets();
        String[] files = null;
        try {
            files = assetManager.list("trainneddata");
        } catch (IOException e) {
            Log.e("tag", "Failed to get asset file list.", e);
        }
        if (files != null) {
            for (String filename : files) {
                Log.i("files", filename);
                InputStream in;
                OutputStream out;
                String dirout = DATA_PATH + "tessdata/";
                File outFile = new File(dirout, filename);
                if (!outFile.exists()) {
                    try {
                        in = assetManager.open("trainneddata/" + filename);
                        (new File(dirout)).mkdirs();
                        out = new FileOutputStream(outFile);
                        copyFile(in, out);
                        in.close();
                        out.flush();
                        out.close();
                    } catch (IOException e) {
                        Log.e("tag", "Error creating files", e);
                    }
                }
            }
        }
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }

    private void recognizeText() {
        String language = "eng";
        TessBaseAPI baseApi = new TessBaseAPI();
        baseApi.init(DATA_PATH, language, TessBaseAPI.OEM_TESSERACT_ONLY);
        baseApi.setImage(BinarizationActivity.umbralization);
        textScanned = baseApi.getUTF8Text();
    }


    public void onClick(View view) {
        if (view.getId() == R.id.nextStep) {
            if (MainActivity.CURRENT_PAGE < MainActivity.TOTAL_PAGES) {
                // if pages scanned are less than total pages
                startActivity(new Intent(RecognizerActivity.this, CaptureActivity.class));
            } else {
                // if all pages scanned, then genereate pdf's and save contact
                PdfGenerator.generateImagePdf();
                PdfGenerator.generateText(MainActivity.TITLE,
                        MainActivity.CONTENT);
                PdfGenerator.deleteImageFiles();
                Toast.makeText(this, "PDF's Generated", Toast.LENGTH_SHORT).show();
                ContactWriter contactWriter = new ContactWriter(this);
                contactWriter.addContact(MainActivity.TITLE, MainActivity.CONTENT);
                Toast.makeText(this, "Contact Saved as " + MainActivity.TITLE, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RecognizerActivity.this, MainActivity.class));
            }
        }
    }

    private class copyTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressCopy.show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressCopy.cancel();
            progressOcr.show();

        }

        @Override
        protected Void doInBackground(Void... params) {
            Log.i("CopyTask", "copying..");
            copyAssets();
            return null;
        }
    }

    private class ocrTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressOcr.cancel();
            textExtracted.setText(textScanned);
        }

        @Override
        protected Void doInBackground(Void... params) {
            Log.i("OCRTask", "extracting..");
            recognizeText();
            MainActivity.CONTENT += textScanned;
            MainActivity.CURRENT_PAGE++;
            return null;
        }
    }
}
